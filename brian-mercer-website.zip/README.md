# Brian Mercer's Website

This is my personal/professional site hosted on GitHub Pages.

## 📁 Structure
- `index.html` – homepage
- `/professional/` – work-related info
- `/personal/` – hobbies and interests
- `/assets/` – images, styles, and scripts

## 🛠 Editing
You can edit any `.html` file in a text editor (or GitHub web UI). Look for `<h1>`, `<p>`, or `<ul>` sections.

## 🚀 Deploy
GitHub Pages auto-deploys from this repository!
